export const data=[
    {
        review:"The tutor I have",
        subject:"english",
        source:"feedback form"

    },
    {
        review:"Speedy service that put me in touch with a great tutor.",
        subject:"History",
        source:"feedback form"
    },{
        review:"Great platform to find tutors of all subjects who are dedicated and keen to help you with your studies",
        subject:"science",
        source:"feedback form"
    },{
        review:"Excellent service from tutor hunt and the french tutor. My family was very privileged to have a very devoted,committed, brilliant,friendly and excellent french tutor for my daughter.I will  also always recommend tutor hunt to everyone."
        ,subject:"music",
        source:"feedback form"

    },{
        review:"This website is an amazing place to find the right tutor for anyone my Daughter has a maths tutor and she has got very better."
        ,subject:"french",
        source:"feedback form"

    }
    ,{

        review:"I found your site trustworthy. It was helpful. You also helped me find a lovely, very professional tutor who is absolutely perfect for our needs."
        ,subject:"math",
        source:"feedback form"
    }
]